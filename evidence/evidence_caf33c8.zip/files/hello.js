console.log("hello world");
console.log("hello")
console.log("world")
console.log("move")
console.log("key removed");
var key= AKIAIOSFODNN7EXAMPLE