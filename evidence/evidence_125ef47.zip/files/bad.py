
var = AKIAIOSFODNN7EXAMPLE

key = wJalrXUtnFEMI/K7MDENG+bPxRfiCYEXAMPLEKEY

print("hello")

print("ehllo")

